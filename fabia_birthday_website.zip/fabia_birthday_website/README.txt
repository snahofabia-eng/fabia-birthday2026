FABIA'S BIRTHDAY WEBSITE — QUICK START

CONTENTS
- index.html: the complete responsive website
- assets/: the supplied photos used in the gallery

PREVIEW ON YOUR COMPUTER
1. Extract the ZIP file.
2. Open the fabia_birthday_website folder.
3. Double-click index.html. It should open in your browser.
   (Internet is needed for the Google Fonts; the site itself works without them.)

PERSONALIZE THE MESSAGE
Open index.html in Notepad or VS Code.
- Search for "With lots of love, ♡" and replace it with your name/sign-off.
- Edit the letter paragraphs to make the message more personal.
- The birthday date is shown in the footer as 18 October.

PUBLISH IT SO FABIA CAN OPEN IT ON HER PHONE — FREE OPTION
Netlify Drop:
1. Go to https://app.netlify.com/drop
2. Sign in / create a free account if prompted.
3. Extract this ZIP first.
4. Drag the whole "fabia_birthday_website" folder (the one containing index.html and assets) into the drop area. If the site asks for a folder, do not upload only index.html.
5. Netlify will publish it and give you a public URL ending in netlify.app.
6. Open that URL on your own phone to test it, then send the link to Fabia.
7. You can change the random site name in Netlify's site settings if a nicer available name is offered.

IMPORTANT
- Do not move index.html away from the assets folder; the relative photo paths depend on this layout.
- Anyone with the link can view the page and photos. Only publish photos you have permission to share.
- The page is mobile responsive and does not require installing an app.

BACKGROUND MUSIC
- Includes an original gentle music-box/piano-style birthday melody.
- Tap the 'Play birthday music' button at bottom-right to start or pause it.
- Mobile browsers generally require a tap before audio can play; automatic sound is intentionally avoided.
- Keep assets/birthday-melody.wav in the assets folder when publishing.

AUTOPLAY UPDATE
- The page now attempts to start background music automatically when it opens.
- If the phone/browser blocks autoplay, the first tap anywhere on the page starts the music.
- This fallback is necessary because mobile browsers may block sound autoplay; a website cannot guarantee audible autoplay on every phone.
